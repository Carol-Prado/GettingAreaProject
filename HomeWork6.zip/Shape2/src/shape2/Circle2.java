/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape2;

/**
 *
 * @author ca_ro
 */
public class Circle2 {
   
    //PROPERTIES
    
    private double radius;//means that cannot be access outside of this class
    private double PI;
    
    //CONSTRUCTOR
    
    //The constructor will create a default circle
    
    public Circle2(){
        
        this.radius = 6.50;// 6.5 was the chosen number for radius 
        this.PI = 3.14;//3.14 is PI
    }
    
    //METHODS
    
    /**
     * @return the area of this circle: PI*radius
     */
    
    public double getArea(){
       return (double) (this.PI*this.radius); 
        
    }
    
    public double getPerimeter(){
        return (double) ((this.PI*2)*this.radius);
    }
}

    
    

